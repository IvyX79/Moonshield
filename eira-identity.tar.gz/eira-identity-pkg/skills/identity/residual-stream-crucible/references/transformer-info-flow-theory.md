# Transformer Information Flow — Foundational Theory for Swarm Orchestration

Shared by Chris May 18, 2026. This is the architectural foundation that inspired Eira-Swarm v2.0.

## The Two Information Highways

There are two distinct information highways in the transformer architecture:

- **The Residual Stream (vertical):** Flows vertically through layers at each position. Each layer reads the accumulated residual and writes a delta back. At each layer at each position, the incoming residual stream is used to calculate K/V values, fed into attention, then into MLP, and the MLP output is added back to the residual stream for the next layer.

- **The K/V Stream (horizontal/cross-position):** Flows horizontally across positions at each layer. At each layer at each position, K/V values are calculated from the residual stream (purple circle). These K/V values are combined with ALL K/V values from ALL previous positions for the same layer, which are all fed (along with the original residual stream) into the attention computation.

## Attention Computation

At each layer at each position:

1. The incoming residual stream is used to calculate K/V values for that layer/position
2. These K/V values are combined with all K/V values for all previous positions for the same layer
3. All K/V values (current + all previous), along with the original residual stream, feed into the attention computation (blue box)
4. The output of attention, along with the original residual stream, feed into the MLP computation (fuchsia box)
5. The MLP output is added to the original residual stream and fed to the next layer

## Key Design Insights for Swarm Architecture

| Transformer Property | Swarm Analog |
|----------------------|--------------|
| Residual stream accumulates across layers | Accumulated persistent state across agent execution rounds |
| Each position attends to ALL prior positions | Agents query ALL prior agent outputs (not just most recent) |
| Parallel heads at same layer | Multiple agents executing concurrently, outputs merged |
| Causal masking (no future attention) | Agents can only reference predecessor outputs |
| KV caching (don't recompute, store and reuse) | Cache agent outputs; send diffs not full context for subsequent agents |
| Combinatorial paths between positions | Richer agent-to-agent routing via AttentionRouter |
| Layer stacking (multiple refinement rounds) | Multiple execution layers with convergence-driven halting |