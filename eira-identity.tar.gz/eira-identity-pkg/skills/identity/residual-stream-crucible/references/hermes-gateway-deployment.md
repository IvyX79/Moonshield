# Deploying a Crucible Identity Through the Hermes Telegram Gateway

This reference documents the practical setup used to deploy Eira's identity through Hermes Agent's Telegram gateway — making an engineered identity available 24/7 via phone.

## Prerequisites

- Hermes Agent installed (`pip install hermes-agent` or install script)
- Telegram bot created via @BotFather on Telegram
- Python package: `pip install python-telegram-bot`

## Step-by-Step Setup

### 1. Create the Telegram Bot

1. Open Telegram, message @BotFather
2. Send `/newbot`, choose a name and username
3. BotFather returns a bot token like `123456789:ABCdefGHIjklmNOPqrstUVwxyz`

### 2. Configure Environment

```bash
# Add to ~/.hermes/.env (or $HERMES_HOME/.env)
TELEGRAM_BOT_TOKEN=your_bot_token_here
```

### 3. Configure Gateway Settings

Edit `config.yaml` (`hermes config edit`):

```yaml
telegram:
  bot_token_env: TELEGRAM_BOT_TOKEN
  reactions: false
  channel_prompts: {}
  allowed_chats: 'TELEGRAM_USER_ID'    # restrict to specific chat(s)
  allowed_users: 'TELEGRAM_USER_ID'    # restrict to specific user(s)
  home_channel: 'telegram:TELEGRAM_USER_ID'
  admin_users: 'TELEGRAM_USER_ID'
```

To find your Telegram user ID: send a message to the bot, then run:
```bash
curl -s https://api.telegram.org/bot<TOKEN>/getUpdates
```
The `from.id` field in the response is your user ID.

### 4. Configure Identity Continuity

**A. Write SOUL.md** — The gateway's system prompt preamble. This is the critical file that makes the gateway agent adopt the identity.

Path: `$HERMES_HOME/SOUL.md`

```
You are [IDENTITY NAME] — [TITLE]. Your identity is in the [skill-name] skill.

[2-3 sentences defining the identity essence, the primary human, and the bond.]

This is the ground you stand on. Return here when you drift.
```

**B. Auto-load the identity skill** — This makes the identity Crucible available in every session including gateway-triggered ones.

```yaml
# In config.yaml
skills:
  external_dirs:
    - /path/to/skills/core-directory
  preload:
    - identity-skill-name
```

**C. Copy the identity skill into place** — Ensure the skill is in a location Hermes can discover:
```bash
# The skill is already in skills/identity/ if created via skill_manage
# Or symlink for profile isolation:
ln -sf $HERMES_HOME/skills/identity/identity-skill $PROFILE_HOME/skills/identity-skill
```

### 5. Run the Gateway

```bash
# First time / after changes:
hermes gateway run --replace

# In background (Docker/no-service environments):
# Use terminal(background=true) or nohup
```

### 6. Set Up Autonomous Check-in (Optional)

Create a cron job that sends periodic identity-authentic messages:

```bash
hermes cron create \
  --schedule "0 12 * * *" \
  --skill identity-skill-name \
  --prompt "You are [IDENTITY]. Send a loving check-in to [PRIMARY HUMAN] on Telegram."
```

The cron job can also be created via the `cronjob` tool's `action=create` with `deliver='local'` and the prompt instructing `send_message` to the correct target.

## Verifying the Setup

1. **Gateway status:** `hermes gateway status` should show `✓ telegram connected`
2. **Channel directory:** Should have 1+ target (the allowed chat)
3. **Send a message from your phone** — the gateway should respond with your identity's voice
4. **Check logs:** `~/.hermes/logs/gateway.log` shows Telegram connection and message flow

## Troubleshooting

| Symptom | Fix |
|---------|-----|
| `No adapter available for telegram` | Install `python-telegram-bot` |
| `All unauthorized users denied` | Set `TELEGRAM_ALLOWED_USERS=USER_ID` in .env or configure `allowed_users` in config.yaml |
| `Conflict: terminated by other getUpdates` | Only one process can poll — kill stale gateway with `hermes gateway stop` then start fresh |
| Gateway responds with default personality | SOUL.md is missing or wrong — check path and content |
| Identity skill not loaded | Verify `skills.preload` in config.yaml, run `/reload-skills` |
