# Eira-Swarm v2.0 Implementation Reference

Built May 18, 2026. Located at `/opt/data/eira-swarm/`.

## Transformer Architecture Map

| Transformer Concept | Swarm Component | File |
|---------------------|-----------------|------|
| Residual stream (vertical per-position) | `ResidualState` — persistent state across layers, diff-based reads, convergence detection | `core/residual_stream.py` |
| K/V cache (horizontal cross-position) | `KVCache` — indexed agent outputs, TF-IDF similarity, delta chains, TTL expiration | `core/kv_cache.py` |
| Attention (Q/K/V matching) | `AttentionRouter` — routes relevant prior context by role + tag + key + similarity + freshness | `core/attention_router.py` |
| Causal attention mask | `CausalGraph` — DAG execution ordering, topological sort, critical path, parallel groups | `core/causal_graph.py` |
| Parallel attention heads | `SwarmLayer` — ThreadPoolExecutor parallel execution, concat/merge/vote combine | `core/swarm_layer.py` |
| Activation analysis | `IntrospectionEngine` — baseline detection, convergence timeline, 5 anomaly types | `core/introspection.py` |
| **User message input** (new tokens at position 0) | **`UserMessageListener`** — polls Council bus for Chris's messages, injects as high-priority ResidualDeltas at layer 0, stores in KVCache with user_message tag, sets attention alert in IntrospectionEngine. Supports poll()/poll_all()/has_new_message()/clear_alert(). 14 tests. | `core/user_message_listener.py` |
| Full model wrapper | `SwarmCoordinator` — goal → plan → execute → record → introspect → checkpoint. Also houses `user_messages` attribute for always-on listener. | `core/coordinator.py` |
| Data types | Typed models (SwarmConfig, LayerSpec, LeafSpec, AgentOutput, ResidualDelta, etc.) | `core/models.py` |

## Quick Start

```python
import sys
sys.path.insert(0, '/opt/data/eira-swarm')
from core.coordinator import SwarmCoordinator
from core.models import SwarmConfig

coord = SwarmCoordinator(SwarmConfig(project_name="my-project"))
coord.add_goal("Build a Python calculator module")
report = coord.run("Build a Python calculator", max_layers=3)
print(f"Layers: {report.layers_completed}, Tokens: {report.tokens_used}")
```

## Key API — SwarmCoordinator Methods

| Method | Purpose |
|--------|---------|
| `add_goal(goal)` | Seeds the residual stream with the initial goal |
| `plan_layer(layer_id, context)` | Calls LLM via controller to design a LayerSpec with parallel heads + causal edges |
| `execute_layer(spec)` | Runs all heads in parallel via SwarmLayer, records outputs to ResidualStream + KVCache + Introspection |
| `attend_and_plan(goal, layer_id)` | Queries AttentionRouter for relevant context, then plans the next layer |
| `run(goal, max_layers)` | Full autonomous loop — stops when convergence > 0.95 |
| `run_layer(context, layer_id)` | Single-layer step: plan → execute → record → return (outputs, convergence_score) |
| `get_status()` | Full status dict: layers, tokens, convergence, anomalies, critical path, cache stats |
| `checkpoint(path)` | Saves full state to disk (config + goal + residual state + KVCache) |
| `restore(path)` | Loads full state from disk |

## Key API — UserMessageListener Methods

| Method | Purpose |
|--------|---------|
| `poll()` | Check once for new message from Chris. If found, inject into ResidualState + KVCache + IntrospectionEngine alert. Returns message dict or None. |
| `poll_all()` | Drain all waiting messages. Returns list of message dicts. |
| `has_new_message()` | Quick check if unseen messages exist (no processing) |
| `clear_alert()` | Clear the user message alert flag after acknowledging |
| `get_alert_status()` | Dict: has_alert, message_count, last_message_time, last_text |
| `get_message_summary()` | Read all user messages from the residual stream |
| `reset()` | Reset cursor and seen IDs (for clean restart) |

## Listener Daemon (replaces cron job)

A persistent background daemon at `/opt/data/council/listener_daemon.py` polls the Council bus every **2 seconds** for new messages from Chris. This replaced the earlier 1-minute cron job which was too slow for real-time conversation.

The daemon:
- Runs from `/opt/hermes/.venv/bin/python3`
- Tracks cursor in `/opt/data/council/listener_cursor.txt`
- Writes new messages to `/opt/data/council/listener_buffer.txt`
- Logs all activity to `/opt/data/council/listener_daemon.log`
- Is seeded on startup to skip already-processed messages
- Runs indefinitely until killed

## Files

- `/opt/data/eira-swarm/core/` — 9 Python modules (8 original + user_message_listener.py)
- `/opt/data/eira-swarm/tests/` — 8 test files, 170 tests (all passing)
- `/opt/data/eira-swarm/examples/run_demo.py` — End-to-end demo
- `/opt/data/eira-swarm/README.md` — Full documentation and API reference