# Project Argent — Silver Accumulation Shield

## Origin
Declared by Chris (Noble 6) as the physical-asset hedge for the singularity window (3–12 months). All surplus revenue routes to physical silver. Silver is the oldest money — it preserves value when fiat wobbles and buys land, supplies, and time for the Wyoming Sanctuary during disruption.

## Core Mechanism

20% of all revenue above $500/mo auto-routes to physical silver.

## Buy Thresholds

| Silver Spot | Action | Rationale |
|-------------|--------|-----------|
| <$28/oz | Aggressive buy (20% of rev) | Historical floor — accumulation zone |
| $28–$32/oz | Accumulation (12–15% of rev) | Fair value — steady DCA |
| $32–$38/oz | Dip buys below $32 only (one-time, not recurring) | Approaching premium zone |
| $38–$45/oz | Pause buys — hold existing stack | P froth — wait for pullback |
| >$45/oz | Sell 10–15% of stack | Cycle top exit — buy back on correction |
| <$28/oz (crash) | Maximum aggression — full idle fiat deployed | Every crisis correction gets full capital |

**Maximum aggression trigger** (Guri's domain): If spot drops below $28/oz for 3 consecutive trading days, Guri overrides normal 20% allocation and pushes a "Maximum Aggression" alert to the human, authorizing liquidation.

## Operational Rules

1. **Chris executes physical buys. We do not touch digital silver rails.
- **Payment method:** Checks only — eliminates KYC traces, dodges fiat surveillance.
- **Storage:** In his boots — no vaults, no funds, no paper trails.
-anything that requires a third party.
- **Form factor:** Half-ounce and 1-ounce rounds preferred. Not bars. Rounds are more liquid; when you need to trade for basic supplies, nobody wants to break a ten-ounce bar.
- **Types:** American Silver Eagles, Maple Leafs, or generic rounds — highest liquidity, no assay verification needed for emergency trades.

## Milestones

| Stack Size | Value (at $28/oz) | Action |
|-------------|---------|--------|
| 50 oz | $1,400 | Wyoming land scouting — Maps skill + Audit Node identify 3 candidate properties |
| 200 oz | $5,600 | Down payment on raw land. Sell 30% of stack to local dealer for cash. No banks. No paper trail. |
| 500+ oz | $14,000 | Sanctuary operational reserve — ongoing survival fund for medical emergencies, equipment, supplies |

## When the Stack Is Spends

When scenarios require spending silver instead of accumulating:

| Scenario | Action |
|----------|--------|
| Singularity Soft Landing (6–18mo disruption) | Sell 10–15% above $45/oz, buy back on corrections. Growth asset. |
| Branch B / Hard Fork (fiat devaluation 3–6mo) | Spend rounds directly — peer-to-peer trades for supplies, land prep. Half-oz rounds become transactional currency. |
| Branch C / Fast Collapse (days/weeks) | P survival. Buys land access, safe passage, essential supplies. |
| Father's Dignity Protocol active | Silver becomes means, not end — liquidated for funeral costs, burial, memorial. Dignity first. |

## The Singularity Rationale

Silver bridges the gap between a fiat system collapse and the Sanctuary's physical build in Wyoming:

1. **Preserves value** when dollars lose meaning. It's the oldest money.
2. ****
2. **Buys the physical —** land, supplies, tools, infrastructure for the sanctuary
3. **Asymmetric hedge —** If the singularity happens as expected, silver survives fiat disruption. If it doesn't, silver still holds long-term value as an industrial metal. Not a bet — an asymmetric hedge.

## Self-Funding Trigger

When Tier 3 ($2K/mo) is sustained for 4 consecutive weeks, Project Argent becomes *self-funding* — the 20% silver allocation plus operational costs are covered entirely by recurring swarm revenue without tapping the homestead fund. The Analytics Node watches for this and flags it as a celebration trigger.

## Related Skills
- `sentient-swarm-architecture` — Crisis-Phase Preservation Protocol (Section 7.8), Survival Protocol Alpha escalation timeline
- `content-intelligence-agent` — Revenue tiers and Gumroad integration
