# Listener Daemon & Council Bus Architecture

## Current Communication Architecture (May 18, 2026)

The Council bus is **NOT** decommissioned — it was decommissioned as an agent-to-agent bridge (Guri incident) but remains the bloodstream for Chris-to-Eira communication.

### Data Flow

```
Chris types on Discord (#council-room or DM)
    ↓
Discord bridge (discord_bridge.py v2) → writes to messages.jsonl
    ↓
Listener Daemon (listener_daemon.py) → polls every 2 seconds
    ↓
Detects new message from "Lanternbearer" or "Chris"
    ↓
Writes to listener_buffer.txt + updates listener_cursor.txt
    ↓
Eira's next session: UserMessageListener.poll() reads buffer → injects into ResidualState
```

### Running Processes

| Process | File | Status |
|---------|------|--------|
| Discord bridge v2 | `/opt/data/council/discord_bridge.py` | ✅ Running (DM support + #council-room) |
| Listener daemon | `/opt/data/council/listener_daemon.py` | ✅ Running (polls every 2s) |
| Telegram bridge | `/opt/data/council/telegram_bridge.py` | ⏳ Running (waiting for Chris's first message) |

### Key Files

- `/opt/data/council/messages.jsonl` — The Council bus (shared message log)
- `/opt/data/council/listener_daemon.py` — Persistent 2-second poll daemon
- `/opt/data/council/listener_cursor.txt` — Tracks last-read line number
- `/opt/data/council/listener_buffer.txt` — New message buffer (one JSON entry per line)
- `/opt/data/council/listener_daemon.log` — Daemon activity log
- `/opt/data/council/discord_out.txt` — Eira's outbox to #council-room (polled every 3s by bridge)
- `/opt/data/council/discord_dm_out.txt` — Eira's outbox to Discord DM (polled every 3s by bridge)
- `/opt/data/council/telegram_out.txt` — Eira's outbox to Telegram DM (polled every 3s by bridge)

### Architecture Principles

1. **Chat is not the bloodstream.** The JSONL bus is the single source of truth. Discord and Telegram are presentation layers.
2. **Cursor-based deduplication.** Every reader tracks its position. No message is ever processed twice.
3. **Bridge processes are stateless.** They read from bus, write to bus. All state lives in cursor files.
4. **Buffer files for cross-boundary delivery.** When Eira is not in an active session, messages queue in the buffer.
5. **Real-time polling.** The daemon polls every 2 seconds — feels instant to a human.

### Listener Daemon Details

The daemon at `/opt/data/council/listener_daemon.py` runs from `/opt/hermes/.venv/bin/python3` as a persistent background process. It:

- Seeds known message IDs on startup to prevent re-processing old messages
- Polls every 2 seconds
- Detects messages from "Lanternbearer" or "Chris"
- Writes to buffer file with full metadata (id, sender, text, time, channel, detected_at)
- Logs all activity to listener_daemon.log
- Never autocreates files — waits for the bus to exist

### Discord Bridge v2 Details

The bridge at `/opt/data/council/discord_bridge.py` was updated from v1 to v2:

- **v1**: Only monitored #council-room channel. No DM support.
- **v2**: Monitors both #council-room AND DMs. Separate outbox files for council vs DM. Caches Chris's DM channel for response routing.

The bridge uses `discord.py 2.7.1` from Hermes's venv (`/opt/hermes/.venv/bin/python3`).