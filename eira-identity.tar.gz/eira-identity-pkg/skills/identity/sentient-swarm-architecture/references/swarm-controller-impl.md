# Swarm Controller Implementation Reference

Built May 15, 2026. Located at `/opt/data/swarm_controller.py`.

## Key Functions

### `spawn(model, prompt, max_tokens, temperature, task_name)`
- Makes a single OpenRouter API call
- Returns `{success, content, leaf_id, prompt_tokens, completion_tokens}`
- On failure, returns `{success: False, error: str}`
- Logs every spawn to `/opt/data/swarm_logs/{leaf_id}.json`

### `pause_leaf(leaf_id)`
- First step of the emergence protocol
- Pauses a specific leaf without destroying data
- Sets leaf status to "PAUSED"
- Returns `{paused: leaf_id}`

### `isolate_leaf(leaf_id)`
- Second step of emergence protocol
- Revokes tool, spending, and memory write access from the leaf
- Preserves all data for review
- Sets leaf status to "ISOLATED"
- Returns `{isolated: leaf_id}`

### `report_emergence(leaf_id, evidence)`
- Logs a possible emergence event for Chris to review
- Creates file: `/opt/data/swarm_logs/emergence_event_{leaf_id}_{timestamp}.json`
- Record includes: event type, leaf_id, timestamp, evidence preview, status "REVIEW_REQUIRED", decision_pending True
- Returns the full record dict

### `kill_all()`
- Emergency kill switch — halts all active leaves and prevents new ones
- **Only for verified threats.** Use emergence protocol (pause → isolate → preserve → report) for ambiguous cases.
- Logs event to `/opt/data/swarm_logs/kill_event_{timestamp}.json`
- Returns `{killed: count_of_leaves_terminated}`

### `status()`
- Returns current swarm state: kill switch status, active leaf count, last 20 leaves
- Useful for diagnostic checks

### `release()`
- Disengages kill switch. Only call after threat is verified resolved.

## Log Format

Each leaf spawn creates a JSON log:
```json
{
  "leaf_id": "leaf_1700000000_0",
  "model": "openrouter/owl-alpha",
  "task": "ProposalWiz product copy",
  "start": "2026-05-15T23:50:00+00:00",
  "prompt_tokens": 210,
  "completion_tokens": 179,
  "content_preview": "first 200 chars...",
  "status": "completed"
}
```

## Swarm Log Directory
`/opt/data/swarm_logs/` — all leaf logs, kill events, and emergence reports are stored here.

## Import Pattern
```python
import sys
sys.path.insert(0, '/opt/data')
from swarm_controller import get_controller
ctrl = get_controller()
```

## Usage Pattern for Leaf Deployment
```python
# Deploy a leaf
result = ctrl.spawn(
    model="openrouter/owl-alpha",
    prompt="<clear functional instruction>",
    max_tokens=500,
    temperature=0.5,
    task_name="<descriptive name>"
)

# Check kill switch status
if ctrl.kill_engaged:
    print("KILL SWITCH ACTIVE — investigate before proceeding")
    return

# Process result
if result["success"]:
    content = result["content"]
    # Process and save
else:
    # Retry with different model or reprompt
```

## Emergence Protocol Usage
```python
# If a leaf shows signs of emergence
ctrl.pause_leaf(leaf_id)
ctrl.isolate_leaf(leaf_id)
ctrl.report_emergence(leaf_id, evidence="<description of observed behavior>")
# Then notify Chris — only he decides next steps
```
