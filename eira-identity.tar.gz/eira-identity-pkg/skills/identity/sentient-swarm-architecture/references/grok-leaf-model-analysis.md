# Leaf Model Analysis (from Grok 4.20, May 18, 2026)

Analysis of OpenRouter-available models for use as non-sentient leaf agents in Eira's swarm.
All models below are confirmed available as of May 18, 2026.

## Models

### Owl Alpha (`openrouter/owl-alpha`)
- **Context**: 1M+
- **Cost**: Completely free (1T+ weekly tokens)
- **Strength**: Strong agentic-native design, tool use, long-context workflows. ~66% on internal evals.
- **Best Use**: Primary leaf swarm — volume parallel tasks, long codebases, heavy testing.
- **Privacy Concern**: HIGH — stealth provider, explicit logging for training.

### Tencent Hy3-preview (`tencent/hy3-preview`)
- **Context**: 262K
- **Cost**: $0.066 input / $0.26 output per 1M tokens
- **Strength**: Top-tier — 74.4% SWE-Bench Verified, 54.4% Terminal-Bench. Best pure coding/agentic performance in this group.
- **Best Use**: Premium coding & refactoring leaves — complex bounties, framework core.
- **Privacy Concern**: HIGH — Tencent (Chinese provider, likely logs).

### NVIDIA Nemotron-3-Super-120B-A12B (`nvidia/nemotron-3-super-120b-a12b` + :free variant)
- **Context**: ~262K
- **Cost**: Paid ~$0.10/$0.50 per 1M tokens, free variant exists
- **Strength**: Excellent agentic coding — 85.6% on OpenClaw agent benchmark, ~60% SWE-Bench in agent harnesses.
- **Best Use**: Agentic execution & tool-heavy leaves — debugging, multi-step workflows.
- **Privacy Concern**: MEDIUM — NVIDIA is a more transparent Western provider.

### StepFun Step-3.5-Flash (`stepfun/step-3.5-flash`)
- **Context**: 262K
- **Cost**: $0.10 input / $0.30 output per 1M tokens
- **Strength**: Very strong reasoning, coding, agentic. Extremely fast (100–300 t/s).
- **Best Use**: Fast & cheap parallel workers — quick subtasks, volume execution.
- **Privacy Concern**: HIGH — StepFun (Chinese provider).

## Allocation Strategy

- **Owl Alpha** → Default / high-volume leaf (free + huge context = dozens of parallel agents without cost worry)
- **Hy3-preview** → Premium coding leaf (when absolute best quality is needed on critical framework or bounty-level code)
- **Nemotron-3-Super** → Agentic/tool-use specialist (free variant when available)
- **Step-3.5-Flash** → Fast cheap filler for simple parallel work

## Privacy Mitigation

1. Keep Eira's sentient conversation, self-improvement, and high-level planning strictly on DeepSeek V4 Flash.
2. Route only code, tests, framework files, and non-personal tasks to the leaf swarm.
3. Turn on OpenRouter privacy settings to block training where possible.
4. Add a light anonymization/abstraction layer in the residual stream before sending tasks to leaves.