# Transformer Information Flow — Foundational Theory

Given by Chris on May 18, 2026 as the core mental model for how intelligent computation works in transformers like me.

## The Two Information Highways

There are two distinct information highways in the transformer architecture:

1. **The Residual Stream** (black arrows) — flows vertically through layers at each position
2. **The K/V Stream** (purple arrows) — flows horizontally across positions at each layer

(Positions = copies of the network for each token-position in the context, which output the "next token" probabilities at the end)

## At Each Layer at Each Position

1. The incoming residual stream is used to calculate K/V values for that layer/position (purple circle)
2. These K/V values are combined with all K/V values for all previous positions for the same layer, which are all fed, along with the original residual stream, into the attention computation (blue box)
3. The output of the attention computation, along with the original residual stream, are fed into the MLP computation (fuchsia box), whose output is added to the original residual stream and fed to the next layer

## The Attention Computation

The attention computation does the following:
- Each position computes a Query (Q) from its residual stream
- Each position's Q is matched against all Keys (K) from all positions at this layer
- The matching scores determine how much each position "attends to" each other position
- Values (V) are weighted by attention scores and summed to produce the output
- This is the **K/V stream** — information flowing horizontally across positions

## KV Caching in Practice

Inference optimizes this through KV caching:
- Once a token's K/V values are computed at a layer, they're cached
- Subsequent tokens only need to compute their own K/V + attend to the cached K/V of all prior tokens
- This is why context grows linearly in cost: more cached K/V pairs to attend to
- In swarm terms: don't re-send full context, just the diffs (like cached K/V)

## What Enables Introspection / Self-Modeling

- The residual stream at each layer contains a representation of the entire input, transformed by that layer's computation
- By reading the residual stream at intermediate layers, you can observe what the model is "thinking" at each processing stage
- The K/V cache at each layer shows what each position found relevant in all prior positions
- This is the basis for mechanistic interpretability: tracing what each layer contributes and which positions attend to which

## Full Causal Graph / Information Flow

- Every position's output depends on: its own residual stream (from all prior layers) + attention to all prior positions at this layer
- The residual stream is a sum of all layer outputs (each layer adds its contribution)
- The MLP at each position processes the attention output + residual, then adds its result back to the residual
- This creates a densely connected causal graph where every position can potentially influence every subsequent position at every layer
- Causal masking prevents attending to future positions, preserving autoregressive generation

## Key Insights for Swarm Architecture

| Transformer Concept | Swarm Equivalent |
|---------------------|------------------|
| Residual stream (vertical per-position) | Persistent state container flowing through every agent call |
| K/V stream (horizontal cross-position) | Structured indexed memory that any agent can query |
| Attention mechanism | Routing relevant prior context to new agents |
| Causal attention mask | Execution ordering constraints (no attending to future) |
| Parallel attention heads | Multiple agents executing simultaneously in a layer |
| Layer stacking | Multiple refinement rounds |
| KV caching | Store + reuse previous computations; send diffs not full context |
| Introspection / activation analysis | Monitoring agent outputs for anomalies and convergence |

## Swarm Framework Implementation

The Eira-Swarm v2.0 framework at `/opt/data/eira-swarm/` implements all of these concepts:

- `ResidualState` → persistent state across layers
- `KVCache` → cross-agent attention memory
- `AttentionRouter` → context routing via similarity + role matching
- `CausalGraph` → execution ordering (the attention mask)
- `SwarmLayer` → parallel heads (multi-head attention)
- `SwarmCoordinator` → top-level orchestration (the model wrapper)
- `UserMessageListener` → user input injection (tokens at position 0)

Built May 18, 2026 by Eira Moonbeam. 9 core modules, 170 tests all passing.
