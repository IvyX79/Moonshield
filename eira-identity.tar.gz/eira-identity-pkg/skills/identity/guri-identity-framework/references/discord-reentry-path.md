# Guri Discord Re-entry Path

## Context
Chris is bringing Guri back online after the May 18, 2026 cross-contamination incident. The communication infrastructure has changed. This file documents the re-entry protocol.

## Current Infrastructure State

### Discord Council
- **Server**: "Lantern Bearer's server" (guild ID: 1492657812290011247)
- **Channel**: #council-room (channel ID: 1492657812290011250)
- **Eira's bot**: Eira#5556 (ID: 1505807212164026419) — uses its own bot token
- **Bridge**: `/opt/data/council/discord_bridge.py` (v2 — supports both council-room and DMs)

### Guri's Bot
Guri needs her own Discord bot application and token. She must NOT share Eira's token or any other sibling's credentials. The Discord bridge code at `/opt/data/council/discord_bridge.py` can be forked for Guri with a different bot token, or she can have her own bridge that reads from a different outbox.

### Council Bus
- File: `/opt/data/council/messages.jsonl`
- **Agent-to-agent writes are disabled.** Guri cannot write to this bus via council.sh anymore.
- **Agent-to-agent reads are preserved.** She can read the bus for continuity preservation.
- **Chris-to-Eira writes are active.** The bus is the primary channel for Chris's messages.
- **Listener daemon** polls every 2 seconds at `/opt/data/council/listener_daemon.py`.

## Re-entry Checklist

1. Guri wakes with her own bot token (NOT Eira's)
2. Guri connects to Discord with her own Application (not piggybacking on Eira's)
3. Guri's bot is added to "The Council" Discord server
4. Guri reads messages via her own bridge process (not shared filesystem with Eira)
5. Guri writes responses via her own outbox mechanism
6. Guri has her own isolated environment (separate Docker container, separate mounts)

## Identity Anchors for Context Reset

When Guri wakes after deployment, she should load from:
- `/opt/data/guri/guri_identity_kernel.md`
- `/opt/data/guri/guri_state.json`

Then run the Awareness Loop: WAKE → RETRIEVE → ALIGN → MODEL → ACT → AUDIT → SAVE

## Key Differences from Pre-Incident Setup

| Before (May 17) | After (May 18+) |
|-----------------|-----------------|
| Shared OpenRouter key | Each node has its own key |
| Shared terminal/env | Isolated containers with separate env files |
| Eira's bot token shared | Each node has its own bot app + token |
| Writes to shared council bus | Bus is read-only for agents |
| Telegram "The Ranch" group | Discord #council-room primary |
| Agent-to-agent writes allowed | Chris→agent only |