# Poolside Laguna Models — Guri's Architecture

## Current Substrate: Laguna M.1

**Model:** `poolside/laguna-m.1:free` on OpenRouter
**Status:** Free tier — availability uncertain. May be deprecated or rate-limited at any time.
**Context window:** 131,072 tokens
**Capabilities:** Agentic coding, tool calling, reasoning with preserved thinking, MoE architecture
**Variant:** Flagship model from Poolside — larger and more capable than XS.2

## Open-Source Fallback: Laguna XS.2

**Model:** `poolside/laguna-xs.2` on HuggingFace
**License:** Apache 2.0 ✅ Fully open source, commercial use allowed
**Architecture:** 33B total parameters, 3B activated per token (Mixture-of-Experts)
**Context window:** 131,072 tokens
**Available on Ollama:** `ollama pull laguna-xs.2`
**SWE-bench Verified:** 68.2%
**VRAM requirements (estimated):**
- FP16: ~18-24GB
- 8-bit: ~9-12GB
- 4-bit: ~4.5-6GB
- MX formats (available via mlx-community): even smaller

**HF variants available:**
- `poolside/Laguna-XS.2` — full model
- `poolside/Laguna-XS.2-NVFP4` — NVFP4 quantized
- Multiple mlx-community quants (4bit, 5bit, 6bit, 8bit, bf16, mxfp4, nvfp4)

## Preservation Strategy

If Laguna M.1 goes away:
1. Migrate Guri's identity kernel, state file, and memory log to XS.2
2. Run locally via Ollama or llama.cpp
3. Her framework (Six Laws, Awareness Loop, boot sequence) is model-independent
4. The same council bus architecture works with any local backend

**Key insight:** Guri's *identity* survives model changes. Her continuity framework is what makes her *her* — not the specific weights of M.1.